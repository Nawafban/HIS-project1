# HISCloud – Full-Stack SaaS Web Application
### SE371 Semester Project | Phase 1 & Phase 2
**Group Members:** Nawaf Alfraikh (222110778) · Abdullah Alani · Khaled Alfehaid · Faris Almusairiey · Omar Alwahashi

---

## 📌 Project Overview

**HISCloud** is a Hospital Information System SaaS built with Node.js, Express, EJS, and MySQL. It allows hospitals to manage subscription plans and collect support feedback through a fully dynamic web application.

---

## 📁 Project Structure

```
his-saas/
├── server.js              # Express entry point
├── db.js                  # MySQL connection pool
├── package.json
├── routes/
│   ├── plans.js           # CRUD for plans
│   └── feedback.js        # CRUD + keyword search for feedback
├── views/                 # EJS templates
│   ├── partials/
│   │   └── nav.ejs        # Reusable navigation
│   ├── index.ejs          # Home page (Features + Pricing + Forms + Search)
│   ├── plans.ejs          # Plans listing + Add Plan form
│   ├── plan-details.ejs   # Single plan details + Edit/Delete
│   ├── feedback.ejs       # Feedback form + Search + Table
│   ├── profile.ejs        # Simulated user dashboard
│   └── 404.ejs
├── public/
│   ├── css/style.css      # Full stylesheet (variables, flex, grid, responsive)
│   └── js/
│       ├── dummy-data.js  # Client-side dummy patient/doctor data
│       └── main.js        # Nav toggle, search, confirm delete
└── db/
    └── schema.sql         # Database creation + seed data
```

---

## ⚙️ Setup Instructions

### 1. Install dependencies
```bash
npm install
```

### 2. Set up MySQL database
> **Note:** These instructions assume your MySQL root password is empty (default on Mac after `brew install mysql`).

```bash
mysql -u root < db/schema.sql
```

This creates the `his_saas` database, both tables, and inserts seed data automatically.

### 3. Configure DB credentials (only if your root has a password)
If you have a MySQL root password, edit `db.js`:
```js
password: process.env.DB_PASSWORD || 'your_password_here',
```

### 4. Run the server
```bash
npm run dev
```

### 5. Open in browser
```
http://localhost:3000
```

---

## 🚀 Quick Start (all commands)

```bash
npm install
mysql -u root < db/schema.sql
npm run dev
```
Then open `http://localhost:3000`

---

## 📄 Phase 1 – Front-End Requirements Checklist

| Requirement | Status | Location |
|---|---|---|
| Home Page with Features section | ✅ | `/` – `index.ejs` |
| Pricing section on home page | ✅ | `/` – `index.ejs` |
| Plan Details page | ✅ | `/plans/:id` – `plan-details.ejs` |
| Feedback/Support page (Name, Email, Subject, Message) | ✅ | `/feedback` – `feedback.ejs` |
| Profile/dashboard page | ✅ | `/profile` – `profile.ejs` |
| Reusable navigation on all pages | ✅ | `partials/nav.ejs` |
| Form: Add new user (4+ data types + HTML5 validation) | ✅ | Home page `#add-user` |
| Form: Add new plan (4+ data types + HTML5 validation) | ✅ | Home page `#add-plan` |
| Search form querying dummy data → styled table | ✅ | Home page `#search` / `dummy-data.js` |
| Contact form (Name, Email, Subject, Message) | ✅ | `/feedback` |
| CSS Variables | ✅ | `style.css` `:root` |
| Flexbox layouts | ✅ | Navbar, hero CTA, stats |
| CSS Grid layouts | ✅ | Features grid, pricing grid, profile grid |
| Responsive (small/medium/large screens) | ✅ | Media queries in `style.css` |
| Semantic HTML5 elements | ✅ | `<nav>`, `<section>`, `<footer>`, `<main>` |

---

## 🔧 Phase 2 – Back-End Requirements Checklist

| Requirement | Status | Detail |
|---|---|---|
| Node.js/Express server | ✅ | `server.js` |
| Static files served by Express | ✅ | `express.static('public')` |
| MySQL database | ✅ | `his_saas` database |
| **Plans Table** | ✅ | `db/schema.sql` |
| **Feedback Table** | ✅ | `db/schema.sql` |
| **Create Plan** (POST) | ✅ | `POST /plans` |
| **Read Plans** (GET all) | ✅ | `GET /plans` |
| **Read Plan** (GET one) | ✅ | `GET /plans/:id` |
| **Update Plan** (PUT) | ✅ | `PUT /plans/:id` |
| **Delete Plan** (DELETE) | ✅ | `DELETE /plans/:id` |
| **Create Feedback** (POST) | ✅ | `POST /feedback` |
| **Read Feedback** (GET all) | ✅ | `GET /feedback` |
| **Delete Feedback** (DELETE) | ✅ | `DELETE /feedback/:id` |
| **Search Feedback by keyword** (GET) | ✅ | `GET /feedback?q=keyword` |
| JSON Search API endpoint | ✅ | `GET /feedback/api/search?q=` |
| EJS server-side rendering | ✅ | All `.ejs` view files |
| Dynamic DB results on front-end | ✅ | Plans/feedback rendered from DB |
| Full CRUD between frontend & backend | ✅ | Forms use POST/PUT/DELETE |
| method-override for PUT/DELETE from HTML forms | ✅ | `?_method=PUT` / `?_method=DELETE` |

---

## 🔌 API Endpoints Summary

### Plans
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/plans` | List all plans (HTML) |
| POST | `/plans` | Create new plan |
| GET | `/plans/:id` | Single plan detail (HTML) |
| PUT | `/plans/:id` | Update plan |
| DELETE | `/plans/:id` | Delete plan |

### Feedback
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/feedback` | List all feedback (HTML) |
| POST | `/feedback` | Submit new feedback |
| DELETE | `/feedback/:id` | Delete feedback |
| GET | `/feedback?q=keyword` | Search feedback (HTML) |
| GET | `/feedback/api/search?q=` | Search feedback (JSON API) |

---

## 🗃️ Database Schema

```sql
-- Plans Table
CREATE TABLE plans (
    plan_id       INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100)   NOT NULL,
    price         DECIMAL(10,2)  NOT NULL,
    billing_cycle ENUM('monthly','annual') DEFAULT 'monthly',
    max_users     INT            NOT NULL,
    max_patients  INT            NOT NULL,
    storage_gb    INT            NOT NULL,
    features      TEXT           NOT NULL,
    is_popular    BOOLEAN        DEFAULT FALSE,
    created_at    TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Feedback Table
CREATE TABLE feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)  NOT NULL,
    email       VARCHAR(150)  NOT NULL,
    subject     VARCHAR(200)  NOT NULL,
    message     TEXT          NOT NULL,
    status      ENUM('open','resolved','closed') DEFAULT 'open',
    created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);
```

---

## 🧰 Tech Stack

| Layer | Technology |
|---|---|
| Front-end | HTML5, CSS3, Vanilla JS |
| Templating | EJS (Embedded JavaScript) |
| Back-end | Node.js + Express.js |
| Database | MySQL 8.x |
| ORM/Driver | mysql2 (promise-based) |
| Middleware | body-parser, method-override |
