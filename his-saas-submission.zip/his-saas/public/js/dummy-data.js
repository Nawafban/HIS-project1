// public/js/dummy-data.js
// SE371 Phase 1 – Dummy patient/doctor data for client-side search
const dummyData = [
  { id: "P-001", name: "Ahmed Al-Rashidi",  type: "Patient", department: "Cardiology",   date: "2025-11-10", status: "Active"   },
  { id: "P-002", name: "Sara Al-Ghamdi",    type: "Patient", department: "Neurology",    date: "2025-12-02", status: "Active"   },
  { id: "P-003", name: "Khalid Al-Otaibi",  type: "Patient", department: "Orthopedics",  date: "2026-01-15", status: "Inactive" },
  { id: "P-004", name: "Fatima Al-Zahrani", type: "Patient", department: "Pediatrics",   date: "2026-02-08", status: "Active"   },
  { id: "P-005", name: "Omar Al-Harbi",     type: "Patient", department: "General",      date: "2026-03-20", status: "Active"   },
  { id: "D-001", name: "Dr. Nora Al-Subaie",type: "Doctor",  department: "Cardiology",   date: "2024-03-01", status: "Active"   },
  { id: "D-002", name: "Dr. Tariq Al-Amer", type: "Doctor",  department: "Neurology",    date: "2024-06-15", status: "Active"   },
  { id: "D-003", name: "Dr. Hessa Al-Qahtani",type:"Doctor", department: "Pediatrics",   date: "2023-09-10", status: "Active"   },
  { id: "S-001", name: "Rania Al-Dosari",   type: "Staff",   department: "Reception",    date: "2024-01-20", status: "Active"   },
  { id: "S-002", name: "Majed Al-Shammari", type: "Staff",   department: "Lab",          date: "2024-04-05", status: "Active"   },
];
