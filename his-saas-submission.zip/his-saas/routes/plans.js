// routes/plans.js – CRUD endpoints for plans
const express = require('express');
const router  = express.Router();
const db      = require('../db');

// Helper: parse features JSON safely
function parseFeatures(plan) {
  try {
    plan.featuresArr = JSON.parse(plan.features);
  } catch {
    plan.featuresArr = [];
  }
  return plan;
}

/* ── GET /plans ── list all plans (EJS page) ───────────────────────── */
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM plans ORDER BY price ASC');
    rows.forEach(parseFeatures);
    res.render('plans', { plans: rows, title: 'Pricing Plans', success: req.query.success, error: null });
  } catch (err) {
    console.error(err);
    res.render('plans', { plans: [], title: 'Pricing Plans', success: null, error: 'Database error.' });
  }
});

/* ── GET /plans/:id ── single plan detail page ──────────────────────── */
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM plans WHERE plan_id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).render('404', { title: 'Not Found' });
    const plan = parseFeatures(rows[0]);
    res.render('plan-details', { plan, title: plan.name + ' Plan' });
  } catch (err) {
    console.error(err);
    res.redirect('/plans');
  }
});

/* ── POST /plans ── create a new plan ───────────────────────────────── */
router.post('/', async (req, res) => {
  const { name, price, billing_cycle, max_users, max_patients, storage_gb, features, is_popular } = req.body;
  // Convert features textarea (one per line) to JSON array
  const featuresArr = features.split('\n').map(f => f.trim()).filter(Boolean);
  const featuresJson = JSON.stringify(featuresArr);
  const popular = is_popular === 'on' ? 1 : 0;
  try {
    await db.query(
      'INSERT INTO plans (name, price, billing_cycle, max_users, max_patients, storage_gb, features, is_popular) VALUES (?,?,?,?,?,?,?,?)',
      [name, price, billing_cycle, max_users, max_patients, storage_gb, featuresJson, popular]
    );
    res.redirect('/plans?success=Plan+created+successfully');
  } catch (err) {
    console.error(err);
    res.redirect('/plans?error=Failed+to+create+plan');
  }
});

/* ── PUT /plans/:id ── update an existing plan ──────────────────────── */
router.put('/:id', async (req, res) => {
  const { name, price, billing_cycle, max_users, max_patients, storage_gb, features, is_popular } = req.body;
  const featuresArr = features.split('\n').map(f => f.trim()).filter(Boolean);
  const featuresJson = JSON.stringify(featuresArr);
  const popular = is_popular === 'on' ? 1 : 0;
  try {
    await db.query(
      'UPDATE plans SET name=?, price=?, billing_cycle=?, max_users=?, max_patients=?, storage_gb=?, features=?, is_popular=? WHERE plan_id=?',
      [name, price, billing_cycle, max_users, max_patients, storage_gb, featuresJson, popular, req.params.id]
    );
    res.redirect('/plans?success=Plan+updated');
  } catch (err) {
    console.error(err);
    res.redirect('/plans?error=Failed+to+update+plan');
  }
});

/* ── DELETE /plans/:id ── delete a plan ─────────────────────────────── */
router.delete('/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM plans WHERE plan_id = ?', [req.params.id]);
    res.redirect('/plans?success=Plan+deleted');
  } catch (err) {
    console.error(err);
    res.redirect('/plans?error=Failed+to+delete+plan');
  }
});

/* ── GET /api/plans ── JSON API: list all plans ─────────────────────── */
router.get('/api/all', async (req, res) => {
  const [rows] = await db.query('SELECT * FROM plans ORDER BY price ASC');
  rows.forEach(parseFeatures);
  res.json(rows);
});

module.exports = router;
