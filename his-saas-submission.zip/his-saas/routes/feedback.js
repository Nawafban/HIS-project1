// routes/feedback.js – Create / Read / Delete + keyword search
const express = require('express');
const router  = express.Router();
const db      = require('../db');

/* ── GET /feedback ── list all feedback (EJS page) ──────────────────── */
router.get('/', async (req, res) => {
  const keyword = req.query.q || '';
  try {
    let rows;
    if (keyword) {
      const like = `%${keyword}%`;
      [rows] = await db.query(
        `SELECT * FROM feedback
         WHERE name LIKE ? OR subject LIKE ? OR message LIKE ?
         ORDER BY created_at DESC`,
        [like, like, like]
      );
    } else {
      [rows] = await db.query('SELECT * FROM feedback ORDER BY created_at DESC');
    }
    res.render('feedback', { feedback: rows, keyword, title: 'Feedback & Support', success: req.query.success, error: null });
  } catch (err) {
    console.error(err);
    res.render('feedback', { feedback: [], keyword: '', title: 'Feedback & Support', success: null, error: 'Database error.' });
  }
});

/* ── POST /feedback ── submit new feedback ──────────────────────────── */
router.post('/', async (req, res) => {
  const { name, email, subject, message } = req.body;
  try {
    await db.query(
      'INSERT INTO feedback (name, email, subject, message) VALUES (?,?,?,?)',
      [name, email, subject, message]
    );
    res.redirect('/feedback?success=Thank+you!+Your+message+has+been+received.');
  } catch (err) {
    console.error(err);
    res.redirect('/feedback?error=Failed+to+submit+feedback');
  }
});

/* ── DELETE /feedback/:id ── delete feedback entry ──────────────────── */
router.delete('/:id', async (req, res) => {
  try {
    await db.query('DELETE FROM feedback WHERE feedback_id = ?', [req.params.id]);
    res.redirect('/feedback?success=Feedback+deleted');
  } catch (err) {
    console.error(err);
    res.redirect('/feedback?error=Failed+to+delete');
  }
});

/* ── GET /api/feedback/search?q=keyword ── JSON search API ──────────── */
router.get('/api/search', async (req, res) => {
  const keyword = req.query.q || '';
  const like = `%${keyword}%`;
  try {
    const [rows] = await db.query(
      `SELECT * FROM feedback WHERE name LIKE ? OR subject LIKE ? OR message LIKE ? ORDER BY created_at DESC`,
      [like, like, like]
    );
    res.json({ count: rows.length, results: rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
