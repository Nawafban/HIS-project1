-- ============================================================
-- SE371 SaaS Project - Hospital Information System
-- Database Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS his_saas;
USE his_saas;

-- --------------------------------------------------------
-- Plans Table
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS plans (
    plan_id       INT AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100)   NOT NULL,
    price         DECIMAL(10,2)  NOT NULL,
    billing_cycle ENUM('monthly','annual') NOT NULL DEFAULT 'monthly',
    max_users     INT            NOT NULL,
    max_patients  INT            NOT NULL,
    storage_gb    INT            NOT NULL,
    features      TEXT           NOT NULL,   -- JSON array of feature strings
    is_popular    BOOLEAN        NOT NULL DEFAULT FALSE,
    created_at    TIMESTAMP      DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- --------------------------------------------------------
-- Feedback Table
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)  NOT NULL,
    email       VARCHAR(150)  NOT NULL,
    subject     VARCHAR(200)  NOT NULL,
    message     TEXT          NOT NULL,
    status      ENUM('open','resolved','closed') NOT NULL DEFAULT 'open',
    created_at  TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------------------------------------
-- Seed Data – Plans
-- --------------------------------------------------------
INSERT INTO plans (name, price, billing_cycle, max_users, max_patients, storage_gb, features, is_popular) VALUES
('Starter',  49.99,  'monthly', 5,   500,   10,
 '["Patient records management","Appointment scheduling","Basic reporting","Email support","Up to 5 staff accounts"]',
 FALSE),

('Professional', 149.99, 'monthly', 25, 5000, 50,
 '["Everything in Starter","Doctor portal access","Advanced analytics","Priority support","Prescription management","Lab results integration","Up to 25 staff accounts"]',
 TRUE),

('Enterprise', 399.99, 'monthly', 999, 999999, 500,
 '["Everything in Professional","Unlimited staff accounts","Multi-hospital support","Custom integrations","24/7 dedicated support","HIPAA compliance tools","Data export & BI tools","SLA guarantee"]',
 FALSE);

-- --------------------------------------------------------
-- Seed Data – Feedback
-- --------------------------------------------------------
INSERT INTO feedback (name, email, subject, message, status) VALUES
('Ahmed Al-Rashidi',  'ahmed@hospital.sa',  'Login issue',              'Cannot log in after password reset. Browser shows 403.',       'open'),
('Sara Al-Ghamdi',    'sara@clinic.sa',     'Feature request',          'Please add bulk patient import from Excel.',                   'open'),
('Khalid Al-Otaibi',  'khalid@medcenter.sa','Billing question',         'Is the annual plan billed upfront or monthly?',               'resolved'),
('Fatima Al-Zahrani', 'fatima@hospital.sa', 'Performance issue',        'Dashboard loads slowly when filtering by date range.',        'open'),
('Omar Al-Harbi',     'omar@clinic.sa',     'Excellent service',        'The appointment module saved us hours every week. Thank you!', 'closed');
