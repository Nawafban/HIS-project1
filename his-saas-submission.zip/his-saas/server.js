// server.js – SE371 SaaS Project Entry Point
const express        = require('express');
const bodyParser     = require('body-parser');
const methodOverride = require('method-override');
const path           = require('path');

const plansRouter    = require('./routes/plans');
const feedbackRouter = require('./routes/feedback');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── View engine ─────────────────────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ── Middleware ───────────────────────────────────────────────────────────────
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(methodOverride('_method'));   // allows PUT/DELETE from HTML forms

// ── Routes ───────────────────────────────────────────────────────────────────
app.get('/', (req, res) => res.render('index', { title: 'HIS – Hospital Information System' }));
app.get('/profile', (req, res) => res.render('profile', { title: 'My Profile' }));
app.use('/plans',    plansRouter);
app.use('/feedback', feedbackRouter);

// 404
app.use((req, res) => res.status(404).render('404', { title: 'Page Not Found' }));

// ── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => console.log(`✅  HIS SaaS running → http://localhost:${PORT}`));
